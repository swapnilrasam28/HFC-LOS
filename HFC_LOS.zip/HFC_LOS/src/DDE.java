import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class DDE extends LOS
{
	public static WebDriverWait wait;
	public static boolean staleElement; 
	
	public static void existingProspect() throws InterruptedException
	{
		Thread.sleep(2000);
		WebElement transactions= driver.findElement(By.xpath("//*[@id='nav']/ul/li[2]/a"));
		Actions a = new Actions(driver);
		a.moveToElement(transactions).build().perform();
		wait =new WebDriverWait(driver, 30);
		WebElement newLoanExpressEntry= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='nav']/ul/li[2]/ul/li[1]/a")));
		newLoanExpressEntry.click();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtProspectNo']")).sendKeys("17163139");
		//driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtProspectNo']")).sendKeys(prospectNo);
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_btnSearchProspect']")).click();
	}
	
	public static void currentResidenceVerification() throws InterruptedException, AWTException, IOException
	{
		//**Current Residence Verification		
		//driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//span[text()='Initialise Verification']")).click();
		driver.switchTo().frame("iframetab");
		driver.findElement(By.xpath("//*[@id='__tab_tblClientDetails_tblClientData']")).click();
		Select applicantName=new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_ddlapplicant']")));
		applicantName.selectByIndex(1);
					
		Select s=new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_leftlistbox_0']")));	
		s.selectByIndex(0);
					
		driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_btnright_0']")).click();
		
		try 
		{
			driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_rdboutstation_0_0_0']")).click();
		} 
		catch (StaleElementReferenceException e) 
		{
			driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_rdboutstation_0_0_0']")).click();
		}
		
		try 
		{
			wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_cmblocation_0']")));
			Select location = new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_cmblocation_0']")));
			location.selectByVisibleText("KARNAL");
		} 
		catch (StaleElementReferenceException e) 
		{
			wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_cmblocation_0']")));
			Select location = new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_cmblocation_0']")));
			location.selectByVisibleText("KARNAL");
		}
			
		try 
		{
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_cmbVendor_0']")));
			Select vendorName=new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_cmbVendor_0']")));
			vendorName.selectByVisibleText("Mahesh Gupta");
		}
		catch (StaleElementReferenceException e) 
		{
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_cmbVendor_0']")));
			Select vendorName=new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_cmbVendor_0']")));
			vendorName.selectByVisibleText("Mahesh Gupta");
		}
		driver.findElement(By.xpath("//*[@id='tblClientDetails_tblClientData_gvParentDetails_grvDetails_0_btnAssign_0']")).click();
		acceptAlert();
		acceptAlert();
		Logout.logout();
				
		//Vendor Login- Mahesh Gupta
		MaheshGupta.mahesh();
						
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtProspectNo']")).sendKeys("17163139");
		//driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtProspectNo']")).sendKeys(prospectNo);
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_btnSearchProspect']")).click();
		driver.switchTo().frame("ContentPlaceHolder1_iframetab");
		driver.findElement(By.xpath("//*[@id='grvDetails_imgview_0']")).click();
//		wait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.name("ifrm")));
		Thread.sleep(2000);
		driver.switchTo().frame("ifrm");
		
//		WebDriverWait wait=new WebDriverWait(driver,10);
//		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='txtAgent']")));
		
		driver.findElement(By.xpath("//*[@name='txtAgent' and @id='txtAgent']")).sendKeys("fdhfhd");	
		driver.findElement(By.xpath("//*[@id='dtDR']")).click();
		driver.findElement(By.xpath("//*[@id='caldtDR_today']")).click();
		driver.findElement(By.xpath("//*[@id='rdbResult_0']")).click();
		
		try 
		{
			driver.findElement(By.xpath("//*[@id='txtRemark']")).sendKeys("fdhfhd");
		}
		catch (StaleElementReferenceException e) 
		{
			driver.findElement(By.xpath("//*[@id='txtRemark']")).sendKeys("fdhfhd");
		}
		
		driver.findElement(By.xpath("//*[@id='txtPrsnMet']")).sendKeys("fdhfhd");
		driver.findElement(By.xpath("//*[@id='txtApplicntRelatn']")).sendKeys("fdhfhd");
				
		Select maritialStatus=new Select(driver.findElement(By.xpath("//*[@id='cmbMStatus']")));
		maritialStatus.selectByVisibleText("Single");
			
		Select otherEarningMember=new Select(driver.findElement(By.xpath("//*[@id='cmbSpouse']")));
		otherEarningMember.selectByVisibleText("No");
				
		Select residenceStatus=new Select(driver.findElement(By.xpath("//*[@id='cmbResStatus']")));
		residenceStatus.selectByVisibleText("Owned");
				
		Select noOfYears=new Select(driver.findElement(By.xpath("//*[@id='cmbResidence']")));
		noOfYears.selectByVisibleText("4-6");
				
		Select isNamePlate=new Select(driver.findElement(By.xpath("//*[@id='cmbOHouse']")));
		isNamePlate.selectByVisibleText("Yes");
				
		Select locality=new Select(driver.findElement(By.xpath("//*[@id='cmbLocality']")));
		locality.selectByVisibleText("Above Average");
		
		Select locatingAddressIs=new Select(driver.findElement(By.xpath("//*[@id='cmbLocatingAddress']")));
		locatingAddressIs.selectByVisibleText("Easy");
				
		Select typeOfAccomodation=new Select(driver.findElement(By.xpath("//*[@id='cmbAccomodation']")));
		typeOfAccomodation.selectByVisibleText("Flat/Apartment");
				
		Select area=new Select(driver.findElement(By.xpath("//*[@id='cmbArea']")));
		area.selectByVisibleText("400-750");
				
		Select doNeighboursRecognize=new Select(driver.findElement(By.xpath("//*[@id='cmbNeighbour']")));
		doNeighboursRecognize.selectByVisibleText("Yes");
				
		Select assetsSeen=new Select(driver.findElement(By.xpath("//*[@id='chkAsst']")));
		assetsSeen.selectByVisibleText("Television");
		assetsSeen.selectByVisibleText("Fridge");
		assetsSeen.selectByVisibleText("Furniture");
		
		WebElement upload =driver.findElement(By.xpath("//*[@id='flupload1']"));
		//Runtime.getRuntime().exec("C://Users//MITS_Swapnil.R//Desktop//1.exe");
		//wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnupload1']")));
		upload.sendKeys("C://Users//MITS_Swapnil.R//Pictures//Screenshots//a.png");
		driver.findElement(By.xpath("//*[@id='btnupload1']")).click();
		
		acceptAlert();
		acceptAlert();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnSave']")));		
		driver.findElement(By.xpath("//*[@id='btnSave']")).click();
		acceptAlert();
		acceptAlert();
		
		driver.findElement(By.xpath("//*[@id='btnmarkcomplete']")).click();
		acceptAlert();
		acceptAlert();
	}
	
	public static void initialiseVerification() throws InterruptedException, AWTException, IOException
	{
		currentResidenceVerification();
		Logout.logout();
		/*
		 * 	Further verification assignment logic to be added here
		 * 	Current residence verification logic is implemented and working fine
		 */
	}
	
	public static void customerDetails() throws InterruptedException, AWTException
	{
		//*****New Loan Express Entry*****
		//***Customer Details***
			//+++Sourcing Details+++	
			
			driver.switchTo().defaultContent();
			driver.switchTo().frame("iframetab");
			driver.switchTo().frame("iframetab");
			wait=new WebDriverWait(driver,10);
			Select specialScheme = new Select(wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='ddlsplscheme']"))));
			specialScheme= new Select(driver.findElement(By.xpath("//*[@id='ddlsplscheme']")));
			specialScheme.selectByVisibleText("Normal");
			driver.findElement(By.xpath("//*[@id='btnSaveUp']")).click();
			
			acceptAlert();
			acceptAlert();
			
			//+++Client Details+++
				//***Occuptation Details***
				driver.switchTo().defaultContent();
				driver.switchTo().frame("iframetab");
				driver.findElement(By.partialLinkText("Client Details")).click();
				driver.switchTo().frame("iframetab");
				driver.findElement(By.partialLinkText("Ocupation Details")).click();
				driver.switchTo().frame("iframetab");
				Select currentEmployer=new Select(driver.findElement(By.xpath("//*[@id='ddlEmployerName']")));
				currentEmployer.selectByVisibleText("IDFC Ltd.");
				
				driver.findElement(By.xpath("//*[@id='txtOfficeEmail']")).sendKeys("abc@idfc.com");
				driver.findElement(By.xpath("//*[@id='txtCurrentJobEmp']")).sendKeys("5");
				driver.findElement(By.xpath("//*[@id='txtTotalExp']")).sendKeys("7");
				
				Select typeOfEmployer=new Select(driver.findElement(By.xpath("//*[@id='cmbtypeoforganisation']")));
				typeOfEmployer.selectByVisibleText("PVT LTD COMPANY");
				
				driver.findElement(By.xpath("//*[@id='txtDepartment']")).sendKeys("IT");
				driver.findElement(By.xpath("//*[@id='txtDesignation']")).sendKeys("Test Engineer");
				driver.findElement(By.xpath("//*[@id='txtEmployeeId']")).sendKeys("DG5661");
				
				Select marginalProfile=new Select(driver.findElement(By.xpath("//*[@id='cmbMarginalProfile']")));
				marginalProfile.selectByVisibleText("NO");
				
				WebElement groupEmployee=driver.findElement(By.xpath("//*[@id='rdbgrpemployee_1']"));
				groupEmployee.click();
				
				try 
				{
					WebElement save = driver.findElement(By.xpath("//*[@id='btnSaveOccu']"));
					Actions actions = new Actions(driver);
					actions.moveToElement(save).click().perform();
				}
				catch (StaleElementReferenceException e) 
				{
					WebElement save = driver.findElement(By.xpath("//*[@id='btnSaveOccu']"));
					Actions actions = new Actions(driver);
					actions.moveToElement(save).click().perform();
				}
				
				acceptAlert();
				acceptAlert();
				
				//***Asset Details***
				driver.switchTo().defaultContent();
				driver.switchTo().frame("iframetab");
				driver.findElement(By.partialLinkText("Client Details")).click();
				driver.switchTo().frame("iframetab");
				try
				{
					driver.findElement(By.partialLinkText("Asset Details")).click();
				}
				catch(StaleElementReferenceException x)
				{
					driver.findElement(By.partialLinkText("Asset Details")).click();
				}
				driver.switchTo().frame("iframetab");
				
				driver.findElement(By.xpath("//*[@id='txtImmovables']")).sendKeys("0");
				driver.findElement(By.xpath("//*[@id='txtSecurities']")).sendKeys("0");
				driver.findElement(By.xpath("//*[@id='txtOtherinvest']")).sendKeys("0");
				driver.findElement(By.xpath("//*[@id='txtBankbal']")).sendKeys("150000");
				
				wait=new WebDriverWait(driver,10);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnFinancialDataSave']")));
				driver.findElement(By.xpath("//*[@id='btnFinancialDataSave']")).click();
				
				acceptAlert();
				acceptAlert();
				
				//***Existing Loan Details***
				driver.switchTo().defaultContent();
				driver.switchTo().frame("iframetab");
				driver.findElement(By.linkText("Client Details")).click();
				driver.switchTo().frame("iframetab");
				
				try 
				{
					driver.findElement(By.linkText("Existing Loan Details")).click();
				}
				catch (StaleElementReferenceException e) 
				{
					driver.findElement(By.linkText("Existing Loan Details")).click();
				}
								
				//driver.findElement(By.partialLinkText("Existing Loan Details")).click();
				driver.switchTo().frame("iframetab");
				
				Select existingLoanType=new Select(driver.findElement(By.xpath("//*[@id='drpdnLoanType']")));
				existingLoanType.selectByVisibleText("Two Wheeler Loan (TWL)");
				Thread.sleep(1000);
				try 
				{
					Select financialInstituteName = new Select(driver.findElement(By.xpath("//*[@id='txtdrpdnSourceHead']")));
					financialInstituteName.selectByVisibleText("FB0017-Kotak Bank");
				} 
				catch (StaleElementReferenceException e) 
				{
					Select financialInstituteName = new Select(driver.findElement(By.xpath("//*[@id='txtdrpdnSourceHead']")));
					financialInstituteName.selectByVisibleText("FB0017-Kotak Bank");
				}
			
				driver.findElement(By.xpath("//*[@id='txtOrgLoanAmt']")).clear();
				driver.findElement(By.xpath("//*[@id='txtOrgLoanAmt']")).sendKeys("100000");
				driver.findElement(By.xpath("//*[@id='txtEMI']")).clear();
				driver.findElement(By.xpath("//*[@id='txtEMI']")).sendKeys("5000");
				driver.findElement(By.xpath("//*[@id='txtAccNo']")).clear();
				try 
				{
					driver.findElement(By.xpath("//*[@id='txtAccNo']")).sendKeys("54164165146");
				}
				catch (StaleElementReferenceException e) 
				{
					driver.findElement(By.xpath("//*[@id='txtAccNo']")).sendKeys("54164165146");
				}
								
				driver.findElement(By.xpath("//*[@id='txtLoanStartDate']")).sendKeys("01/03/2017");
				
				Select status=new Select(driver.findElement(By.xpath("//*[@id='ddlstatus']")));
				status.selectByVisibleText("Active");
				
				wait=new WebDriverWait(driver,10);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnSave']")));
				driver.findElement(By.xpath("//*[@id='btnSave']")).click();
				
				acceptAlert();
				acceptAlert();
				
				//***Bank Details***
				driver.switchTo().defaultContent();
				driver.switchTo().frame("iframetab");
				driver.findElement(By.partialLinkText("Client Details")).click();
				driver.switchTo().frame("iframetab");
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id='6']/a/span")).click();
				driver.switchTo().frame("iframetab");
				
				driver.findElement(By.xpath("//*[@id='chkIsPrimary']")).click();
				driver.findElement(By.xpath("//*[@id='txtAccountNo']")).sendKeys("104402548948");
				Select accType=new Select(driver.findElement(By.xpath("//*[@id='ddlAccountType']")));
				accType.selectByVisibleText("10 - Simple Saving");
				
				driver.findElement(By.xpath("//*[@id='ddlBankCode']")).sendKeys("icici");
				WebElement bankCodeSearch=driver.findElement(By.xpath("//*[@id='Image4']"));
				bankCodeSearch.click();
				String parentWindow1=driver.getWindowHandle();
				System.out.println("Parent Window"+parentWindow1);
				for(String childWindow1 : driver.getWindowHandles())
				{
					driver.switchTo().window(childWindow1);
					System.out.println("Child Window"+childWindow1);
				}
				driver.findElement(By.xpath("//*[@id='gvsourcing_lnkVendor_1']")).click();
				System.out.println(parentWindow1);
				driver.switchTo().window(parentWindow1);
				
				driver.switchTo().frame("iframetab");
				driver.switchTo().frame("iframetab");
				driver.switchTo().frame("iframetab");
				//*[@id='Image4']
				driver.findElement(By.xpath("//*[@id='ddlBranchCode']")).sendKeys("icici");
				WebElement branchCodeSearch=driver.findElement(By.xpath("//*[@id='Image5']"));
				branchCodeSearch.click();
				parentWindow1=driver.getWindowHandle();
				//System.out.println(parentWindow);
				for(String childWindow1 : driver.getWindowHandles())
				{
					driver.switchTo().window(childWindow1);
					System.out.println(childWindow1);
				}
				driver.findElement(By.xpath("//*[@id='gvsourcing_lnkVendor_1']")).click();
				System.out.println(parentWindow1);
				driver.switchTo().window(parentWindow1);
				
				driver.switchTo().frame("iframetab");
				driver.switchTo().frame("iframetab");
				driver.switchTo().frame("iframetab");
				
				wait=new WebDriverWait(driver,10);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnSaveBank']")));
				driver.findElement(By.xpath("//*[@id='btnSaveBank']")).click();
				
				acceptAlert();
				acceptAlert();
				
				//***Reference Details***
				driver.switchTo().defaultContent();
				driver.switchTo().frame("iframetab");
				driver.findElement(By.partialLinkText("Client Details")).click();
				driver.switchTo().frame("iframetab");
				Thread.sleep(1000);
				driver.findElement(By.xpath("//*[@id='7']/a/span")).click();
				driver.switchTo().frame("iframetab");
				
					//***Reference 1***
					driver.findElement(By.xpath("//*[@id='txtRefName']")).sendKeys("asdsad");
					Select relation=new Select(driver.findElement(By.xpath("//*[@id='txtRelation']")));
					relation.selectByVisibleText("Brother");
					
					driver.findElement(By.xpath("//*[@id='txtRefAdd1']")).sendKeys("Thane");
					driver.findElement(By.xpath("//*[@id='txtRefPincode']")).sendKeys("400610");
					
					Select country=new Select(driver.findElement(By.xpath("//*[@id='cmbCountry']")));
					country.selectByVisibleText("IND-INDIA");
					Select state=new Select(driver.findElement(By.xpath("//*[@id='cmbState']")));
					state.selectByVisibleText("MH-Maharashtra");
					Select city=new Select(driver.findElement(By.xpath("//*[@id='cmbCity']")));
					city.selectByVisibleText("022T-THANE");
					 
					driver.findElement(By.xpath("//*[@id='txtMobile']")).sendKeys("9167630094");
					driver.findElement(By.xpath("//*[@id='txtPhone']")).sendKeys("022");
					
					wait=new WebDriverWait(driver,10);
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnsave']")));
					driver.findElement(By.xpath("//*[@id='btnsave']")).click();
					
					acceptAlert();
					acceptAlert();
					
					//***Reference 2***
					driver.findElement(By.xpath("//*[@id='txtRefName']")).sendKeys("fdhgfdh");
					relation=new Select(driver.findElement(By.xpath("//*[@id='txtRelation']")));
					relation.selectByVisibleText("Brother");
					
					driver.findElement(By.xpath("//*[@id='txtRefAdd1']")).sendKeys("Thane");
					driver.findElement(By.xpath("//*[@id='txtRefPincode']")).sendKeys("400610");
					
					country=new Select(driver.findElement(By.xpath("//*[@id='cmbCountry']")));
					country.selectByVisibleText("IND-INDIA");
					state=new Select(driver.findElement(By.xpath("//*[@id='cmbState']")));
					state.selectByVisibleText("MH-Maharashtra");
					city=new Select(driver.findElement(By.xpath("//*[@id='cmbCity']")));
					city.selectByVisibleText("022T-THANE");
					 
					driver.findElement(By.xpath("//*[@id='txtMobile']")).sendKeys("9167630094");
					driver.findElement(By.xpath("//*[@id='txtPhone']")).sendKeys("022");
					
					wait=new WebDriverWait(driver,10);
					wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnsave']")));
					driver.findElement(By.xpath("//*[@id='btnsave']")).click();
					acceptAlert();
					acceptAlert();

			//+++Loan and property Details+++	
			driver.switchTo().defaultContent();
			driver.switchTo().frame("iframetab");
			driver.findElement(By.xpath("//span[text()='Loan and propery Details']")).click();
			
				//***Property Details***
				driver.switchTo().frame("iframetab");
				//driver.findElement(By.xpath("//*[@id='__tab_tblClientDetails_tabCost']")).click();
				
				Select typeOfConstruction=new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_drpdnConstruction']")));
				typeOfConstruction.selectByVisibleText("Ready");
				
				driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_rbtCollateral_0']")).click();
				driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_rbtCollateral_0']")).sendKeys(Keys.TAB);
				driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_ddlOwnerOfProperty']")).sendKeys(Keys.ARROW_DOWN,Keys.TAB);
				//driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_ddlOwnerOfProperty']/option[2]")).click();
				driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_txtFloorFlatNo']")).sendKeys("15");
											
				driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_txtPnumber']")).sendKeys("25");
				driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_txtLocality']")).sendKeys("Thane");
				driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_txtRateOfInterest']")).sendKeys("8.35");
				
				Select propertyCountry=new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_txtCountryprop']")));
				propertyCountry.selectByVisibleText("INDIA");
				
				Select propertyState=new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_txtStateprop']")));
				propertyState.selectByVisibleText("Maharashtra");
				
				Select propertyCity=new Select(driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_txtCityprop']")));
				propertyCity.selectByVisibleText("THANE");
				
				driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_txtpincodeprop']")).sendKeys("400601");
				
				wait=new WebDriverWait(driver,10);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='tblClientDetails_tabCost_btnsavepropDetails']")));
				driver.findElement(By.xpath("//*[@id='tblClientDetails_tabCost_btnsavepropDetails']")).click();
				
				acceptAlert();
				acceptAlert();
				
				//***Loan Details***
				driver.findElement(By.xpath("//*[@id='__tab_tblClientDetails_TabPanel1']")).click();
				driver.findElement(By.xpath("//*[@id='tblClientDetails_TabPanel1_txtRateofIntExp']")).clear();
				driver.findElement(By.xpath("//*[@id='tblClientDetails_TabPanel1_txtRateofIntExp']")).sendKeys("8.35");
				driver.findElement(By.xpath("//*[@id='tblClientDetails_TabPanel1_txtNetIncomeExp']")).clear();
				driver.findElement(By.xpath("//*[@id='tblClientDetails_TabPanel1_txtNetIncomeExp']")).sendKeys("700000");
				driver.findElement(By.xpath("//*[@id='tblClientDetails_TabPanel1_txtPropertyValExp']")).clear();
				driver.findElement(By.xpath("//*[@id='tblClientDetails_TabPanel1_txtPropertyValExp']")).sendKeys("12000000");	
				driver.findElement(By.xpath("//*[@id='tblClientDetails_TabPanel1_ddlGoverningAuth']")).sendKeys("Municipal Authority");
				
				wait=new WebDriverWait(driver,10);
				wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='tblClientDetails_TabPanel1_btnsaveBankDetails']")));
				driver.findElement(By.xpath("//*[@id='tblClientDetails_TabPanel1_btnsaveBankDetails']")).click();
				
				acceptAlert();
				acceptAlert();
	}
	
	public static void underwriting() throws InterruptedException, AWTException
	{
		//***UnderWriting Details***
			//***Risk and PSL Categorization***
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//*[@id='2']/a/span")).click();
			driver.switchTo().frame("iframetab");
			driver.findElement(By.xpath("//*[@id='0']/a/span")).click();
			driver.switchTo().frame("iframetab");
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
			
			acceptAlert();
			acceptAlert();
			
			//***Customer Income***
			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//*[@id='2']/a/span")).click();
			driver.switchTo().frame("iframetab");
			driver.findElement(By.xpath("//*[@id='1']/a/span")).click();
			driver.switchTo().frame("iframetab");
			WebElement tickBox =driver.findElement(By.xpath("//*[@id='grvDetails_IsRequired_4']"));
			tickBox.click();
			
			try 
			{
				driver.findElement(By.xpath("//*[@id='grvDetails_CamType_4']")).click();
			} 
			catch (StaleElementReferenceException e) 
			{
				driver.findElement(By.xpath("//*[@id='grvDetails_CamType_4']")).click();
			}
				
			driver.switchTo().frame("frame1");
			
			Select applicantType=new Select(driver.findElement(By.xpath("//*[@id='drpdnAppType']")));
			applicantType.selectByVisibleText("APPLICANT");
			
			wait=new WebDriverWait(driver,10);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='drpdnAppName']")));
			
			try 
			{
				Select applicantName = new Select(driver.findElement(By.xpath("//*[@id='drpdnAppName']")));
				applicantName.selectByIndex(1);
			} 
			catch (StaleElementReferenceException e) 
			{
				Select applicantName = new Select(driver.findElement(By.xpath("//*[@id='drpdnAppName']")));
				applicantName.selectByIndex(1);
			}
			
			try 
			{
				Select loanType = new Select(driver.findElement(By.xpath("//*[@id='drploantype']")));
				loanType.selectByVisibleText("HL");
			} 
			catch (StaleElementReferenceException e) 
			{
				Select loanType = new Select(driver.findElement(By.xpath("//*[@id='drploantype']")));
				loanType.selectByVisibleText("HL");
			}
			
			try 
			{
				Select propertyType = new Select(driver.findElement(By.xpath("//*[@id='drppropertytype']")));
				propertyType.selectByVisibleText("APF");
			} 
			catch (StaleElementReferenceException e)
			{
				Select propertyType = new Select(driver.findElement(By.xpath("//*[@id='drppropertytype']")));
				propertyType.selectByVisibleText("APF");
			}
			
			driver.findElement(By.xpath("//*[@id='txtbasic']")).clear();
			driver.findElement(By.xpath("//*[@id='txtbasic']")).sendKeys("20000");
			driver.findElement(By.xpath("//*[@id='txtHRA']")).clear();
			driver.findElement(By.xpath("//*[@id='txtHRA']")).sendKeys("20000");
			driver.findElement(By.xpath("//*[@id='txtSplAllowance']")).clear();
			driver.findElement(By.xpath("//*[@id='txtSplAllowance']")).sendKeys("5000");
			
			wait=new WebDriverWait(driver,10);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnCalculate']")));
			
			driver.findElement(By.xpath("//*[@id='btnCalculate']")).click();
			acceptAlert();
			driver.findElement(By.xpath("//*[@id='btnSave']")).click();
			acceptAlert();
			driver.findElement(By.xpath("//*[@id='btnCancel']")).click();
			
			//***Personal Discussion***

			driver.switchTo().defaultContent();
			driver.findElement(By.xpath("//*[@id='2']/a/span")).click();
			driver.switchTo().frame("iframetab");
			driver.findElement(By.xpath("//*[@id='2']/a/span")).click();
			driver.switchTo().frame("iframetab");
			
			driver.findElement(By.xpath("//*[@id='__tab_tbPersonalDiscussion_tpPersonaldetails']")).click();
			driver.findElement(By.xpath("//*[@id='grvClientData']/tbody/tr[2]/td[1]")).click();
			
			try 
			{
				driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpPersonaldetails_txtName']")).sendKeys("dsfds");
			} 
			catch (StaleElementReferenceException e)
			{
				driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpPersonaldetails_txtName']")).sendKeys("dsfds");
			}
			
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpPersonaldetails_txtAge']")).sendKeys("24");
			Select qualification=new Select(driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpPersonaldetails_txtQualification']")));  
			qualification.selectByVisibleText("GRAD-GRADUATE");
			
			Select relation=new Select(driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpPersonaldetails_txtRelation']")));
			relation.selectByVisibleText("Self");
			
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpPersonaldetails_btnPersonaldetailsSave']")).click();
			acceptAlert();
			alertWait();
			acceptAlert();
			
			driver.findElement(By.xpath("//*[@id='__tab_tbPersonalDiscussion_tpFamilydetails']")).click();
			
			try 
			{
				driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpFamilydetails_txtFamilyName']")).sendKeys("dsgv");
			}
			catch (StaleElementReferenceException e) 
			{
				driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpFamilydetails_txtFamilyName']")).sendKeys("dsgv");
			}
			
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpFamilydetails_txtNoofDependents']")).sendKeys("2");
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpFamilydetails_btnFamilyDetailSave']")).click();
			acceptAlert();
			acceptAlert();
			
			driver.findElement(By.xpath("//*[@id='__tab_tbPersonalDiscussion_tpOffice']")).click();
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpOffice_txtTotalworkexperience']")).sendKeys("5");
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpOffice_btnOfficeDetailSave']")).click();
			acceptAlert();
			acceptAlert();

			
			driver.findElement(By.xpath("//*[@id='__tab_tbPersonalDiscussion_tpBudgetAnalysis']")).click();
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpBudgetAnalysis_txtNameofBank']")).sendKeys("asd");
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpBudgetAnalysis_txtProductLoanamount']")).sendKeys("0");
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpBudgetAnalysis_txtEMI']")).sendKeys("0");
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpBudgetAnalysis_btnLiabilitiesSave']")).click();
			
			acceptAlert();
			acceptAlert();
			
			driver.findElement(By.xpath("//*[@id='grvClientData']/tbody/tr[2]/td[3]")).click();
			driver.findElement(By.xpath("//*[@id='__tab_tbPersonalDiscussion_tpother']")).click();
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpother_txtDateofdiscussion']")).click();
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpother_caltxtDateofdiscussion_today']")).click();
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpother_txtPlaceofDiscussion']")).sendKeys("2dsgfds8");
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpother_txtNameOfTheOfficer']")).sendKeys("2dsgfds8");
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpother_chkPhyApp_0']")).click();
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpother_chkCustBehav_0']")).click();
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpother_txtComments']")).sendKeys("2dsgfds8");
			driver.findElement(By.xpath("//*[@id='tbPersonalDiscussion_tpother_btnOtherSave']")).click();
			
			acceptAlert();
			acceptAlert();
			
			//***Decision***
	}
	
	public static void newLoanExpressEntry() throws InterruptedException, AWTException, IOException
	{
		existingProspect();
		//customerDetails();	
		initialiseVerification();
		//underwriting();	
		
		//Logout.logout();
	}
}
