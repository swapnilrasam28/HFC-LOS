import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Login extends LOS
{
	public static void login() throws InterruptedException, IOException
	{
		String path=System.getProperty("user.dir");
		XSSFWorkbook workBook=new XSSFWorkbook(new FileInputStream(new File(path+"/Test Data/AppTestData.xlsx")));
		String userId= (String)workBook.getSheetAt(0).getRow(0).getCell(1).getStringCellValue();
		String password= (String)workBook.getSheetAt(0).getRow(1).getCell(1).getStringCellValue();
				
		driver.findElement(By.xpath("//*[@id='txtPassword']")).sendKeys(password);
		driver.findElement(By.xpath("//*[@id='txtUserName']")).sendKeys(userId);
		//driver.findElement(By.xpath("//*[@id='txtPassword']")).sendKeys(password);
		
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnLogin']")));
		driver.findElement(By.xpath("//*[@id='btnLogin']")).click();
		wait=new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='AppTable']/tbody/tr/td[2]/div/span[1]/label")));
		driver.findElement(By.xpath("//*[@id='AppTable']/tbody/tr/td[2]/div/span[1]/label")).click();
		
		workBook.close();
	}	
}
