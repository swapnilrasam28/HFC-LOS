import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MaheshGupta extends DDE
{
	public static void mahesh() throws InterruptedException
	{
		driver.findElement(By.xpath("//*[@id='txtPassword']")).sendKeys("iifl@123");
		driver.findElement(By.xpath("//*[@id='txtUserName']")).sendKeys("V3044");
		WebDriverWait wait=new WebDriverWait(driver,30);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='btnLogin']")));
		driver.findElement(By.xpath("//*[@id='btnLogin']")).click();
		wait=new WebDriverWait(driver,10);
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='main-content']/div[1]/a")));
		driver.findElement(By.xpath("//*[@id='main-content']/div[1]/a")).click();
		Thread.sleep(2000);
		for(String winHandle:driver.getWindowHandles())
		{
		    driver.switchTo().window(winHandle);
		}
	}
}
