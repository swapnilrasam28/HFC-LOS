import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReadytToLogin extends LOS
{
	public static void readyToLogin() throws InterruptedException, IOException, AWTException
	{
		//***Ready to Login***
		
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_btnReadyToLogin']")).click();
		acceptAlert();
		acceptAlert();
		
		//***My Queue***
		Thread.sleep(3000);
		WebElement newLogin1= driver.findElement(By.xpath("//*[@id='nav']/ul/li[4]/a"));
		Actions a6 = new Actions(driver);
		a6.moveToElement(newLogin1).build().perform();
		WebDriverWait w2 =new WebDriverWait(driver, 30);
		WebElement myQueue= w2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='nav']/ul/li[4]/ul/li[3]/a")));
		myQueue.click();  	

		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_grvProcess_Accept_0']")).click();
		
		acceptAlert();	
		acceptAlert();
		
	}
}
