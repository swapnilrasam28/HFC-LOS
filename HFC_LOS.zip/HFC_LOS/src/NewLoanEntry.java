import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class NewLoanEntry extends LOS
{
	public static boolean staleElement = true;
	public static String newLoanEntry() throws InterruptedException, IOException, AWTException 
	{
		String path=System.getProperty("user.dir");
		XSSFWorkbook workBook=new XSSFWorkbook(new FileInputStream(new File(path+"/Test Data/AppTestData.xlsx")));
		
		//***New Login***
		WebElement newLogin= driver.findElement(By.xpath("//*[@id='nav']/ul/li[4]/a"));
		Actions a1 = new Actions(driver);
		a1.moveToElement(newLogin).build().perform();
		WebDriverWait w1 =new WebDriverWait(driver, 30);
		WebElement newLoanEntry= w1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='nav']/ul/li[4]/ul/li[1]/a")));
		newLoanEntry.click();
				
		//***New Loan Entry***
		String firstName= (String)workBook.getSheetAt(1).getRow(0).getCell(1).getStringCellValue();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txt_fname']")).sendKeys(firstName);
		
		String middleName= (String)workBook.getSheetAt(1).getRow(1).getCell(1).getStringCellValue();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtmname']")).sendKeys(middleName);
		
		String lastName= (String)workBook.getSheetAt(1).getRow(2).getCell(1).getStringCellValue();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtlname']")).sendKeys(lastName);
		
		WebElement male=driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_rb_male']"));
		male.click();
		//WebElement female=driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_rb_female']"));
		//female.click();
		
		String mobNo= (String)workBook.getSheetAt(1).getRow(3).getCell(1).getRawValue().toString();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txt_contact']")).sendKeys(mobNo);
		
		String sourcingPerson= (String)workBook.getSheetAt(1).getRow(4).getCell(1).getStringCellValue();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtrm']")).sendKeys(sourcingPerson);
		
		WebElement sourcingPersonSearch=driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_ImageButton4']"));
		sourcingPersonSearch.click();
				
		String parentWindow=driver.getWindowHandle();
		System.out.println("Parent Window"+parentWindow);
		for(String childWindow : driver.getWindowHandles())
		{
			driver.switchTo().window(childWindow);
			System.out.println("Parent Window"+childWindow);
		}
		driver.findElement(By.xpath("//*[@id='grdVendor_lnkVendor_0']")).click();
		driver.switchTo().window(parentWindow);
		
		Thread.sleep(2000);
		Select project = new Select(driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_ddlProject']"))); 
		project.selectByVisibleText("SWARAJ");
		
		Select product = new Select(driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_ddlproduct']"))); 
		product.selectByVisibleText("HOME LOAN SWARAJ");
				
		String loanAmount= (String)workBook.getSheetAt(1).getRow(5).getCell(1).getRawValue().toString();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txt_amount']")).sendKeys(loanAmount);
		
		String tenor= (String)workBook.getSheetAt(1).getRow(6).getCell(1).getRawValue().toString();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txt_tenure']")).sendKeys(tenor);
		
		Select source = new Select(driver.findElement(By.xpath("//*[@id='ddlsource']"))); 
		source.selectByVisibleText("Branch WALKIN");
				
		//Select loanPurpose = new Select(driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_ddlpurpose']"))); 
		//loanPurpose.selectByVisibleText("Asset Purchase");
		
		while(staleElement) 
		{
			try 
			{
				Select loanPurpose = new Select(driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_ddlpurpose']"))); 
				loanPurpose.selectByVisibleText("Housing Loan");    
				staleElement = false;
			}
			catch (StaleElementReferenceException e) 
			{
				staleElement = true;
			}
		}		
			
		//***IMD Details***
		driver.findElement(By.xpath("//*[@id='ui-id-2']")).click();
		String chequeNo= (String)workBook.getSheetAt(1).getRow(7).getCell(1).getRawValue().toString();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txt_ImdChequeNo']")).sendKeys(chequeNo);
		
		String bankName= (String)workBook.getSheetAt(1).getRow(9).getCell(1).getStringCellValue();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txtbankname']")).sendKeys(bankName);
		
		WebElement bankNameSearch=driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_Image2']"));
		bankNameSearch.click();
				
		parentWindow=driver.getWindowHandle();
		//System.out.println(parentWindow);
		for(String childWindow1 : driver.getWindowHandles())
		{
			driver.switchTo().window(childWindow1);
			System.out.println(childWindow1);
		}
		driver.findElement(By.xpath("//*[@id='grdVendor_lnkVendor_1']")).click();
		driver.switchTo().window(parentWindow);
		String amount= (String)workBook.getSheetAt(1).getRow(8).getCell(1).getRawValue().toString();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_txt_ImdAmount']")).sendKeys(amount);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_btn_sub']")).click();
		workBook.close();		
		
		acceptAlert();
		acceptAlert();
				
		driver.findElement(By.xpath("//*[@id='ui-id-1']")).click();
		prospectNo=driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_lblProspectNo']")).getText();
		System.out.println(prospectNo);
		
		return prospectNo;
		
	}
}
