import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Logout extends LOS 
{
	public static void logout()
	{
		//***Logout***
		driver.switchTo().defaultContent();
		WebDriverWait w1 = new WebDriverWait(driver, 30);
		WebElement userName= w1.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='lblUserName']")));
		//visibilityOfElementLocated(By.xpath("//*[@id='lblUserName']")));
		
		userName= driver.findElement(By.xpath("//*[@id='lblUserName']"));
		Actions a2 = new Actions(driver);
		a2.moveToElement(userName).build().perform();
		WebDriverWait w2 = new WebDriverWait(driver, 30);
		WebElement logOut= w2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='btnLogOut' and @title='Log Out']")));
		logOut.click();
		Alert a = driver.switchTo().alert();
		a.accept();
	}
}
