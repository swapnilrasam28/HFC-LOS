import java.awt.AWTException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Random;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class QDE extends LOS
{
	public static String path=System.getProperty("user.dir");
	public static XSSFWorkbook workBook;
	public static boolean staleElement; 
	public static StringBuffer pan, aadhar;
	
	public static void aadhar()
	{
		aadhar = new StringBuffer();
		Random rad=new Random();
		int a=rad.nextInt(900000000) + 1000000000;
		int b=rad.nextInt(90)+10;
		aadhar.append(a).append(b);
	}

	public static void pan()
	{
	   String CharSet = "ABCDEFGHJKLMNOPQRSTUVWXYZ";
	   String Token = "";
	   for (int a = 1; a <= 5; a++) 
	   {
		   Token += CharSet.charAt(new Random().nextInt(CharSet.length()));
	   }
	   String CharSet1 = "0123456789";
	   String Token1 = "";
	   for (int a = 1; a <= 4; a++) 
	   {
		   Token1 += String.valueOf(new Random().nextInt(CharSet1.length()));
	   }
	   char Token2;
	   Token2= CharSet.charAt(new Random().nextInt(CharSet.length())); 
	   pan = new StringBuffer();
	   pan.append(Token).append(Token1).append(Token2);
	}
	
	public static void existing() throws InterruptedException
	{
		WebElement newLogin= driver.findElement(By.xpath("//*[@id='nav']/ul/li[4]/a"));
		Actions a = new Actions(driver);
		a.moveToElement(newLogin).build().perform();
		WebDriverWait wait =new WebDriverWait(driver, 30);
		WebElement newLoanExpressEntry= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='nav']/ul/li[4]/ul/li[2]/a")));
		newLoanExpressEntry.click();
		driver.findElement(By.xpath("//*[@id='ContentPlaceHolder1_tbPrelogin_tpNormal_grvDetails_Details_99']")).click();
	}
	
	public static void qde() throws InterruptedException, AWTException, FileNotFoundException, IOException
	{
		
		workBook=new XSSFWorkbook(new FileInputStream(new File(path+"/Test Data/AppTestData.xlsx")));
		
		//*****QDE*****
		//***Customer Details***
		//existing();		
		
		Thread.sleep(3000);
		driver.switchTo().frame("iframetab");
		Select propertyIdentification = new Select(driver.findElement(By.id("ddlPIdentification")));
		propertyIdentification.selectByVisibleText("Identified");
						
		driver.findElement(By.xpath("//*[@id='btnSaveLoan']")).click();
		acceptAlert();
		acceptAlert();
		
		String title= (String)workBook.getSheetAt(2).getRow(1).getCell(1).getStringCellValue();
		Select salutation= new Select(driver.findElement(By.xpath("//*[@id='cmbTitleExp']")));
		salutation.selectByVisibleText(title);
		
		String fatherName= (String)workBook.getSheetAt(2).getRow(2).getCell(1).getStringCellValue();
		driver.findElement(By.xpath("//*[@id='txtFatherExp']")).sendKeys(fatherName);
		
		String motherName= (String)workBook.getSheetAt(2).getRow(3).getCell(1).getStringCellValue();
		driver.findElement(By.xpath("//*[@id='txtMotherExp']")).sendKeys(motherName);
		
		driver.findElement(By.xpath("//*[@id='dtpDOBExp']")).sendKeys("01/07/1990");
		
		String status= (String)workBook.getSheetAt(2).getRow(5).getCell(1).getStringCellValue();
		Select maritialStatus= new Select(driver.findElement(By.xpath("//*[@id='cmbMartialExp']")));
		maritialStatus.selectByVisibleText(status);
		
		String income= (String)workBook.getSheetAt(2).getRow(6).getCell(1).getStringCellValue();
		Select incomeType = new Select(driver.findElement(By.xpath("//*[@id='ddlincometype']")));
		incomeType.selectByVisibleText(income);
		
		driver.findElement(By.xpath("//*[@id='btnSaveExistingCust']")).click();
		acceptAlert();
	
		isElementPresent();
		
		//***Identity Details***
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//*[@id='1']/a/span")).click();
		driver.switchTo().frame("iframetab");
		pan();
		try 
		{
			driver.findElement(By.xpath("//*[@id='txtPANno']")).sendKeys(pan.toString());
			staleElement = false;
		} 
		catch (StaleElementReferenceException e) 
		{
			driver.findElement(By.xpath("//*[@id='txtPANno']")).sendKeys(pan.toString());
			staleElement = false;
		}
				
		aadhar();
		driver.findElement(By.xpath("//*[@id='txtAdharNo']")).sendKeys(aadhar.toString());
		
		String email= (String)workBook.getSheetAt(2).getRow(7).getCell(1).getStringCellValue();
		driver.findElement(By.xpath("//*[@id='txtEmail']")).sendKeys(email);
		
		driver.findElement(By.xpath("//*[@id='btnSaveIdentity']")).click();
				
		acceptAlert();
				
		try
		{
			Thread.sleep(2000);	
			WebDriverWait wait=new WebDriverWait(driver,15);
			wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='tabPANVerification_tblClientData_rdIsMatched_0']")));
			WebElement PANMatched=driver.findElement(By.xpath("//*[@id='tabPANVerification_tblClientData_rdIsMatched_0']"));
			PANMatched.click();
			//WebElement PANNotMatched=driver.findElement(By.xpath("//*[@id='tabPANVerification_tblClientData_rdIsMatched_1']"));
			//PANNotMatched.click();
			driver.findElement(By.xpath("//*[@id='tabPANVerification_tblClientData_btnSave']")).click();
			acceptAlert();
			acceptAlert();
		}
		catch (UnhandledAlertException uae) 
		{
		    try
		    {
		        Alert alert = driver.switchTo().alert();
		        String alertText = alert.getText();
		        System.out.println("Alert data: " + alertText);
		        alert.accept();
		    }
		    catch (NoAlertPresentException e) 
			{
			     e.printStackTrace();
			}
		}
		
		//***Address Details***
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//*[@id='2']/a/span")).click();
		driver.switchTo().frame("iframetab");
		Thread.sleep(2000);
		Select address = new Select(driver.findElement(By.xpath("//*[@id='drpdnAddressDetails']")));
		address.selectByVisibleText("CURRENT RESIDENCE");
		
		try 
		{
			WebElement isMailing = driver.findElement(By.xpath("//*[@id='chkMAddress']"));
			isMailing.click();	
		} 
		catch (StaleElementReferenceException e) 
		{
			WebElement isMailing = driver.findElement(By.xpath("//*[@id='chkMAddress']"));
			isMailing.click();
		}
								
		driver.findElement(By.xpath("//*[@id='txtAdd1Exp']")).sendKeys("Thane");
		driver.findElement(By.xpath("//*[@id='txtAdd2Exp']")).sendKeys("Thane");
		driver.findElement(By.xpath("//*[@id='txtAdd3Exp']")).sendKeys("Thane");
				
		driver.findElement(By.xpath("//*[@id='txtCityExp']")).sendKeys("Thane");
		driver.findElement(By.xpath("//*[@id='imgCity']")).click();
		parentWindow=driver.getWindowHandle();
		for(String childWindow1 : driver.getWindowHandles())
		{
			driver.switchTo().window(childWindow1);
		}
		driver.findElement(By.xpath("//*[@id='gvsourcing_lnkVendor_0']")).click();
		driver.switchTo().window(parentWindow);
			
		driver.switchTo().frame("iframetab");
		driver.findElement(By.xpath("//*[@id='txtArea']")).sendKeys("Thane");
		driver.findElement(By.xpath("//*[@id='ibgArea']")).click();		
		parentWindow=driver.getWindowHandle();
		for(String childWindow1 : driver.getWindowHandles())
		{
			driver.switchTo().window(childWindow1);
		}
		driver.findElement(By.xpath("//*[@id='gvsourcing_lnkVendor_1']")).click();
		driver.switchTo().window(parentWindow);
		
		driver.switchTo().frame("iframetab");
		driver.findElement(By.xpath("//*[@id='txtContact4']")).sendKeys("022");
		driver.findElement(By.xpath("//*[@id='txtContact1']")).sendKeys("9167630094");
		
		Select ownershipType=new Select(driver.findElement(By.xpath("//*[@id='drpdnResidneceType']")));
		ownershipType.selectByVisibleText("CP-Company Provided");
		
		driver.findElement(By.xpath("//*[@id='txtStdymonthsExp']")).sendKeys("5");
		
		Select residenceStatus=new Select(driver.findElement(By.xpath("//*[@id='drpdnResidneceStatus']")));
		residenceStatus.selectByVisibleText("Apartment");
		
		Select locality=new Select(driver.findElement(By.xpath("//*[@id='drpdnLocality']")));
		locality.selectByVisibleText("Upper Middle Class");
		
		Select area=new Select(driver.findElement(By.xpath("//*[@id='drpdnAreaInSqFt']")));
		area.selectByVisibleText("400 - 500");
		
		Select constructionOfHouse=new Select(driver.findElement(By.xpath("//*[@id='drpdnConstructionofHouse']")));
		constructionOfHouse.selectByVisibleText("Concrete");
		
		Select externalAppearance=new Select(driver.findElement(By.xpath("//*[@id='dprnExternalAppearance']")));
		externalAppearance.selectByVisibleText("Excellent");	
		
		driver.findElement(By.xpath("//*[@id='btnSaveAddress']")).click();
		Thread.sleep(2000);
		acceptAlert();
		acceptAlert();
				
			
		//***CIBIL Details***
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//*[@id='3']/a/span")).click();
		driver.switchTo().frame("iframetab");
		driver.findElement(By.xpath("//*[@id='grvClientData_lnkSelect_0']")).click();
		
		WebDriverWait wait = new WebDriverWait(driver, 30);
		wait.until(ExpectedConditions.alertIsPresent());
		acceptAlert();
				
		Select cibilStatus =new Select(driver.findElement(By.xpath("//*[@id='grvClientData_drpstatus_0']")));
		cibilStatus.selectByVisibleText("Positive");
		
		Select crifStatus =new Select(driver.findElement(By.xpath("//*[@id='grvClientData_drpCRIFstatus_0']")));
		crifStatus.selectByVisibleText("Positive");
		
		driver.findElement(By.xpath("//*[@id='grvClientData_btnsubmit_0']")).click();
				
		acceptAlert();
		acceptAlert();
				
		//***Negative Verification***
			
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//*[@id='4']/a/span")).click();
		driver.switchTo().frame("iframetab");
		driver.findElement(By.xpath("//*[@id='txtRemark']")).sendKeys("positive");
		driver.findElement(By.xpath("//*[@id='btnSaveUp']")).click();
		
		acceptAlert();
		
		/*
		WebDriverWait w3 =new WebDriverWait(driver, 60);
		WebElement coApplicant= w3.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[1]/div[3]/div/button[2]/span")));
		coApplicant.click();
		*//////
		isElementPresent();
						
		//***Scheme Master***	
		
		driver.switchTo().defaultContent();
		driver.findElement(By.xpath("//*[@id='5']/a/span")).click();
		driver.switchTo().frame("iframetab");

		try 
		{
			Select scheme = new Select(driver.findElement(By.xpath("//*[@id='cmbScheme']")));
			scheme.selectByVisibleText("HL BT SWARAJ");
		} 
		catch (StaleElementReferenceException e) 
		{
			Select scheme = new Select(driver.findElement(By.xpath("//*[@id='cmbScheme']")));
			scheme.selectByVisibleText("HL BT SWARAJ");
		}
			
		try 
		{
			Select portfolio =new Select(driver.findElement(By.xpath("//*[@id='cmbPortfolio']")));
			portfolio.selectByVisibleText("HOME LOAN SWARAJ");
		} 
		catch (StaleElementReferenceException e) 
		{
			Select portfolio =new Select(driver.findElement(By.xpath("//*[@id='cmbPortfolio']")));
			portfolio.selectByVisibleText("HOME LOAN SWARAJ");
		}
				
		try 
		{
			Select propertyUsage =new Select(driver.findElement(By.xpath("//*[@id='cmbProptUsg']")));
			propertyUsage.selectByVisibleText("Resi");  
		} 
		catch (StaleElementReferenceException e) 
		{
			Select propertyUsage =new Select(driver.findElement(By.xpath("//*[@id='cmbProptUsg']")));
			propertyUsage.selectByVisibleText("Resi");  
		}
		
		try 
		{
			Select transactionType =new Select(driver.findElement(By.xpath("//*[@id='cmbTransType']")));
			transactionType.selectByVisibleText("Purchase Built up");  
		} 
		catch (StaleElementReferenceException e) 
		{
			Select transactionType =new Select(driver.findElement(By.xpath("//*[@id='cmbTransType']")));
			transactionType.selectByVisibleText("Purchase Built up");  
		}
		
		try 
		{
			Select propertyType =new Select(driver.findElement(By.xpath("//*[@id='cmbPropType']")));
			propertyType.selectByVisibleText("APF");  
		} 
		catch (StaleElementReferenceException e) 
		{
			Select propertyType =new Select(driver.findElement(By.xpath("//*[@id='cmbPropType']")));
			propertyType.selectByVisibleText("APF");  
		}
		
		try 
		{
			Select projectLocation =new Select(driver.findElement(By.xpath("//*[@id='cmbProjLoc']")));
			projectLocation.selectByVisibleText("NOIDA");   
		} 
		catch (StaleElementReferenceException e) 
		{
			Select projectLocation =new Select(driver.findElement(By.xpath("//*[@id='cmbProjLoc']")));
			projectLocation.selectByVisibleText("NOIDA"); 
		}
		
		try 
		{
			Select projectName =new Select(driver.findElement(By.xpath("//*[@id='cmbProjName']")));
			projectName.selectByVisibleText("Purvanchal Royal Park");  
		} 
		catch (StaleElementReferenceException e) 
		{
			Select projectName =new Select(driver.findElement(By.xpath("//*[@id='cmbProjName']")));
			projectName.selectByVisibleText("Purvanchal Royal Park"); 
		}
		
		try 
		{
			Select caseType =new Select(driver.findElement(By.xpath("//*[@id='ddlcategory']")));
			caseType.selectByVisibleText("SAL");    
		} 
		catch (StaleElementReferenceException e) 
		{
			Select caseType =new Select(driver.findElement(By.xpath("//*[@id='ddlcategory']")));
			caseType.selectByVisibleText("SAL");   
		}
		
		try 
		{
			Select underwriter =new Select(driver.findElement(By.xpath("//*[@id='ddlcreditor']")));
			underwriter.selectByVisibleText("Asha Singh");    
		} 
		catch (StaleElementReferenceException e) 
		{
			Select underwriter =new Select(driver.findElement(By.xpath("//*[@id='ddlcreditor']")));
			underwriter.selectByVisibleText("Asha Singh");  
		}
		
		driver.findElement(By.xpath("//*[@id='btnSaveScm']")).click();
		
		Thread.sleep(3000);
				
		acceptAlert();
		acceptAlert();
				
		driver.findElement(By.xpath("//*[@id='btnDDE']")).click();
		acceptAlert();	
		
	}
}
