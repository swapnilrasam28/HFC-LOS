import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LOS 
{
	public static WebDriver driver;
	public static String prospectNo,parentWindow;
	public static boolean isPresent = true;
	public static String baseUrl;
	
	public static void getScreenshot() throws IOException 
	{
		File scr=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);

	    File dest= new File("E://"+prospectNo+"//HFC_"+prospectNo+" "+timestamp()+".png");
	    FileUtils.copyFile(scr, dest);
	}
	
	public static void alertWait() throws InterruptedException
	{
		int i = 0;
		while (i++ < 5) 
		{
			try 
			{
				driver.switchTo().alert();
				break;
			} 
			catch (NoAlertPresentException e) 
			{
				Thread.sleep(1000);
				continue;
			}
		}
	}

	public static String timestamp() 
	{
		return new SimpleDateFormat("YYYY-MM-dd HH-MM-SS").format(Calendar.getInstance().getTime());
	}
	
	public static void acceptAlert() throws InterruptedException, AWTException
	{
		try 
		{
			WebDriverWait wait=new WebDriverWait(driver,10);
			wait.until(ExpectedConditions.alertIsPresent());
			
			Alert alert = driver.switchTo().alert();
			String alertMessage= driver.switchTo().alert().getText();
			System.out.println(alertMessage);
			alert.accept();
		} 
		catch (UnhandledAlertException f) 
		{
		    try 
		    {
		        Alert alert = driver.switchTo().alert();
		        String alertText = alert.getText();
		        System.out.println("Alert data: " + alertText);
		        alert.accept();
		    } 
		    catch (NoAlertPresentException e) 
		    {
		        e.printStackTrace();
		    }
		}		
	}
 	
	public static boolean isElementPresent()
	{
		try 
		{
			driver.findElement(By.xpath("/html/body/div[1]/div[3]/div/button[2]/span")).click();
		} 
		catch (NoSuchElementException e) 
		{
			isPresent = false;
		}
		return false;
	}
	
	public static void main(String[] args) throws InterruptedException, IOException, AWTException
	{
		// **** Chrome Driver Initialization
		DesiredCapabilities dc = new DesiredCapabilities();
		dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		System.setProperty("webdriver.chrome.driver", "E:\\Swapnil R\\Selenium Webdriver\\Driver & Libraries\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver(dc);
				
		// **** Gecko Driver Initialization
		//System.setProperty("webdriver.gecko.driver", "E:\\Swapnil R\\Selenium Webdriver\\Driver & Libraries\\geckodriver.exe");
		//System.setProperty("webdriver.firefox.marionette","false");
		//driver=new FirefoxDriver();
				
		driver.navigate().to("http://internaladmin.iifl.in/HFC/loginForm.aspx");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
		
		Login.login();
		NewLoanEntry.newLoanEntry();
		ReadytToLogin.readyToLogin();
		QDE.qde();
		DDE.newLoanExpressEntry();		
//		Logout.logout();		
	}
}
